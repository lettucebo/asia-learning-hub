# Facilitator validation notes

- Scenario company: LaunchPad, fictional digital-native SaaS / Digital Services provider.
- Key date: REL-2410 deployed 20 Oct 2026.
- Primary issue: activation deterioration after signup, concentrated in workspace provisioning and first-project creation.
- Core guardrail: temporal association is not root-cause proof. Per-tenant traces are missing for 18% of requests; no controlled rollback comparison exists.
- Intentional data-quality issues are listed in `known_data_quality_issues.csv`.
- Excel workbook includes an executive dashboard, formatted source data, a formula-driven priority band and heatmap rules.
- All customer segments, counts and ARR values are illustrative synthetic data, not real performance or financial estimates.
