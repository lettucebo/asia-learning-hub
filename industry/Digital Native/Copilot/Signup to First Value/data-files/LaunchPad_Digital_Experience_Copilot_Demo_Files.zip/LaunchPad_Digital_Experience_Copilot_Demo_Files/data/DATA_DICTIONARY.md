# Data dictionary

All data is synthetic.

- `daily_product_journey_metrics.csv`: Daily attempts and performance by customer journey step. Baseline is 12–19 Oct 2026; post-release is 20–25 Oct 2026. Contains intentional training data-quality defects.
- `customer_segment_impact.csv`: Trial and activation counts, estimated at-risk accounts, illustrative annual recurring revenue and priority score by segment and plan. ARR is not realized revenue.
- `customer_support_cases.csv`: Synthetic support case sample with category, priority, response and resolution metrics. Contains intentional missing/text values.
- `release_monitoring.csv`: Daily release-monitoring snapshots around REL-2410, including queue backlog and worker timeouts.
- `release_record_REL-2410.json`: Change summary, known constraints, rollback plan and approval requirements.
- `known_data_quality_issues.csv`: Facilitator index of deliberately seeded data-quality defects; learners should attempt detection before consulting this file.

Priority bands: Critical >=75; High >=55; Medium >=35; Low <35.
